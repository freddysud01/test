export interface MemberInfo
{
    memberId: number;
    first:string;
    last: string;
    jobTitle: string;
    racingTeam: string;
    isActive: boolean;
    
}