export interface User{
    username: String;
    password: String;
}