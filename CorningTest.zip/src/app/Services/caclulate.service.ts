import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { CalculationDTO } from '../Models/CalculationDTO';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CaclulateService {
 
 
  constructor(private httpClient:HttpClient) { }
 
  SendResult(calcDto: CalculationDTO) : Observable<CalculationDTO> {
    console.log('here');
    return this.httpClient.post<CalculationDTO>("https://localhost:44397/api/values/GetData/", calcDto);
  }

  
}
