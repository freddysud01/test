import { Component, OnInit } from '@angular/core';
import { CalculationDTO } from '../Models/CalculationDTO';
import { CaclulateService } from '../Services/caclulate.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  private firstValue: string;
  private secondValue: string;
  private resultValue: number;
  private calcDTO: CalculationDTO;
private textAreaData: Array<CalculationDTO>=[];
  constructor(private calService: CaclulateService) { }

  ngOnInit() {
  }

  GetResult() {
    //happy path i.e presuming the user inputs numbers only
    this.resultValue =  Number.parseInt(this.firstValue) +  Number.parseInt(this.secondValue);
 
    this.calcDTO =  {firstNumber:Number.parseInt(this.firstValue), secondNumber:Number.parseInt(this.secondValue),result:this.resultValue};
    //call to the service
    this.calService.SendResult(this.calcDTO).subscribe((x: CalculationDTO)=>{
      //get data
      this.textAreaData.push(x)
    });
    console.log(this.resultValue);
  }

}
