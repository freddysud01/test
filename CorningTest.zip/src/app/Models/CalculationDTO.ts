export interface CalculationDTO{
    firstNumber: number;
    secondNumber:number;
    result: number;
}