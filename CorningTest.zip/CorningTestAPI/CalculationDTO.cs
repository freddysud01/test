﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CorningTestAPI
{
    public class CalculationDTO
    {
      public int FirstNumber { get; set; }
      public int SecondNumber { get; set; }
      public int Result { get; set; }
        
    }
}
